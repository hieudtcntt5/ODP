# alias to latest
from dbt.artifacts.schemas.manifest.v12.manifest import *  # noqa
