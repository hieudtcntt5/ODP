"""Utilities which are usable by the cli, api or rules."""
